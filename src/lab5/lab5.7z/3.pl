reflection(point(Xa, Ya), point(Xb, Yb)) :-
	=(Xa, Yb), =(Ya, Xb).

test_answer :-
reflection(point(-5, 8), point(X, Y)),
        write(point(X, Y)),
        halt.

test_answer :- write('Wrong answer!'),
               halt.